﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Web_API_MVC_Core.Models;

namespace Web_API_MVC_Core.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AjaxAPIController : ControllerBase
    {
        [Route("AjaxMethod")]
        [HttpPost]
        public PersonModel AjaxMethod(PersonModel person)
        {
            person.DateTime = DateTime.Now.ToString();
            return person;
        }
    }
}
